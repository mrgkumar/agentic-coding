# Fresher and Visual Audit

Reviewed against the rendered course on 2026-08-19. Each learning route now includes a collapsed **New here? Five questions worth asking** section. The questions below are the checks used during review; answers are rendered in the route’s FAQ rather than hidden in implementation notes.

## 00 · Start

1. Do I need prior Claude Code experience?
2. What will I be able to do afterward?
3. Is this a live Claude session?
4. Why does a human appear twice in the workflow?
5. What should I do if I am unsure?

Visual verdict: clear entry point, three use modes, and a readable engineering workflow.

## 01 · From Chat to Agent

1. What is an agent in plain language?
2. What counts as a tool?
3. Is an agent always better than chat?
4. Can tools make Claude correct?
5. Where does the engineer fit?

Visual verdict: the loop is rendered as Context → Decide → Act → Evidence returns, with a text alternative and a mobile-safe stack.

## 02 · Build Context

1. Why build context before asking for a change?
2. What does each ladder step add?
3. Should I read every file?
4. What does a useful summary contain?
5. How do I know I have enough context?

Visual verdict: repository explorer and ladder are distinct, aligned panels; the ladder remains readable when stacked on mobile.

## 03 · Research Before Editing

1. Why calculate the expected value myself?
2. Why investigate before editing?
3. What is known versus inferred?
4. What should research produce?
5. What if the hypothesis is wrong?

Visual verdict: arithmetic, current result, choices, and evidence categories have clear visual grouping.

## 04 · Plan the Change

1. What is a plan?
2. What makes a plan too broad?
3. What must be preserved here?
4. Why say smallest coherent change?
5. Who approves the plan?

Visual verdict: checklist and scope feedback make the review task scannable without pretending a green test is approval.

## 05 · Control Execution

1. How are plan, `/goal`, and `/loop` different?
2. What makes a good goal?
3. When is a loop appropriate?
4. Does a goal approve the result?
5. What should happen when the goal is not met?

Visual verdict: semantic control diagram now shows How? → execution/evidence → When done?, with explicit continue/stop branches.

## 06 · Verify & Accept

1. What should I inspect before accepting?
2. Why can passing tests be insufficient?
3. What is the difference between met and accepted?
4. When should I reject?
5. What is a useful acceptance note?

Visual verdict: evidence checkboxes make the hidden unrelated change concrete and keep acceptance a human judgment.

## 07 · Tools, Permissions & Hooks

1. What does CLAUDE.md do?
2. What do tools do?
3. What do permissions do?
4. What do hooks do?
5. How should I reason about all four?

Visual verdict: four equal cards create a consistent comparison; labels distinguish jobs without relying on color alone.

## 08 · Context, Memory & Subagents

1. What contributes to working context?
2. Why can more context hurt?
3. When is a subagent useful?
4. Are more agents automatically better?
5. What should a handoff contain?

Visual verdict: the context-source diagram is legible as monospace text and is paired with a focused delegation decision.

## 09 · Capstone

1. Why is this scenario different from the calculator?
2. What is ambiguous?
3. What is the correct first move?
4. What should the clarification include?
5. Can “do not edit yet” be a successful outcome?

Visual verdict: repository explorer, terminal evidence, and ambiguity decision form a clear final assessment at desktop and mobile widths.

## Cross-route verification

- Fresh `agent-browser` session: every learning route rendered five FAQ items.
- Desktop screenshots captured for start, context, research, execution, controls, context/subagents, and capstone.
- Mobile expanded FAQ checked at 390px with no horizontal overflow.
- Execution diagram checked at 1440px and 390px with an accessible label.
- `agent-browser errors` was empty across the route audit.
- `npm test` and `git diff --check` passed.
