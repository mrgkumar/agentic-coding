# Course Verification Report

Date: 2026-08-19  
Course version: 1.0  
Target: `http://127.0.0.1:4173/` served from `course/`

## Build and tests

- ✓ `npm test` — the content/invariant test suite passes.
- ✓ Static HTTP serving — Python `http.server` served the course directory.
- ✓ No backend, API key, or package installation is required.

## Browser journeys

- ✓ Start — home exposes Full course, Quick refresher, and Reference paths.
- ✓ Agent — selecting “model + tools + iterative observations” produces strong feedback.
- ✓ Context — repository explorer exposes README, package, source, and tests; the orientation choice produces feedback.
- ✓ Research — ₹2,124 arithmetic, investigation decision, evidence board, and deterministic terminal are present; investigation produces strong feedback.
- ✓ Plan — over-scoped plan can be reviewed; correct scope is fixed-coupon ordering, regression coverage, and preservation constraints.
- ✓ Goal — Plan, `/goal`, and `/loop` remain separate; the completion-condition choice produces feedback.
- ✓ Verification — diff/tests/scope review exposes the unrelated style change and supports rejection.
- ✓ Controls — CLAUDE.md, tools, permissions, and hooks are presented as distinct concepts.
- ✓ Capstone — Pulse Monitor introduces an ambiguous requirement and the correct path is clarification before editing.

## Viewports and visual review

Screenshots captured with agent-browser at 1440×900, 768×1024, and 390×844 (`/tmp/course-desktop.png`, `/tmp/course-tablet.png`, `/tmp/course-mobile.png`). The 320px stress check reported `scrollWidth: 305` for `innerWidth: 320`, with no horizontal overflow.

## Accessibility and runtime

- ✓ `agent-browser snapshot -i` shows semantic landmarks, headings, named links/buttons, labeled groups, and checkboxes.
- ✓ Keyboard-native controls use links, buttons, labels, and visible `:focus-visible` styling.
- ✓ `agent-browser errors` and `agent-browser console` were empty on representative routes.
- Note: this installed agent-browser version exposes accessibility snapshots but does not provide the documented `a11y` subcommand; the snapshot evidence was reviewed instead.

## Answer-leak audit

- ✓ Exercise feedback containers are empty and hidden before learner action.
- ✓ The research page exposes the problem and choices, but not the investigation feedback or diagnosis until selection.
- ✓ No answer is placed in README text, test names, filenames, ARIA labels, or tooltips.

Known limitation: screenshot files are kept in `/tmp` as temporary verification artifacts; the written evidence remains here.

## Beginner visual critique pass

The live app was reviewed as a first-time learner at desktop and 390px mobile widths. Two issues were corrected: the programmatically focused main region no longer draws a distracting black outline, and mobile lesson navigation keeps readable labels until the 320px stress breakpoint. The home route no longer repeats the “Start” module heading above the hero. Relevant lessons now end with a copyable **Try this in Claude Code** prompt, making the bridge from practice to real work explicit. A fresh browser session confirmed the updated prompt, no horizontal overflow, and no runtime errors.

The **From Chat to Agent** lesson received an additional visual/content correction after review: its original vertical stack implied a pipeline rather than a loop. It now labels each stage, explains what each stage means, and explicitly shows evidence returning to context. The diagram has a text alternative for assistive technology and was checked at 1440px, 1068px, 390px, and 320px widths.

The 1068px review also found sticky-header overlap after route focus. Navigation now focuses the new lesson without scrolling it under the header, and `scroll-padding-top` protects anchor/keyboard navigation.

The full per-route fresher question and visual checklist is recorded in [FRESHER_AUDIT.md](FRESHER_AUDIT.md).

The requested 25-page information architecture and stable routes are recorded in [COURSE_STRUCTURE.md](COURSE_STRUCTURE.md). A complete agent-browser matrix opened every route successfully; intermediate pages do not advance module progress until the module’s final page.
