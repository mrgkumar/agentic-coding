# Course Page Structure

The learning app uses stable hash routes so every page is directly reachable on GitHub Pages:

```text
00 Start                         #/start
01 From Chat to Agent            #/agent
02 Build Context                 #/context/orient
  ├─ Orient / repository         #/context/orient
  ├─ Context Ladder              #/context/ladder
  └─ Context summary             #/context/summary
03 Research Before Editing       #/research/problem
  ├─ Problem                     #/research/problem
  ├─ Investigation               #/research/investigation
  └─ Evidence board              #/research/evidence
04 Plan the Change               #/plan/critique
  ├─ Critique bad plan           #/plan/critique
  └─ Approve good plan           #/plan/approve
05 Control Execution             #/execution/controls
  ├─ Plan / goal / loop          #/execution/controls
  ├─ /goal exercise              #/execution/goal
  └─ /loop micro-example         #/execution/loop
06 Verify & Accept               #/verification/goal
  ├─ Goal met?                   #/verification/goal
  ├─ Diff / test review          #/verification/review
  └─ Scope-creep challenge       #/verification/scope
07 Tools / Permissions / Hooks   #/controls/overview
  └─ Control scenarios           #/controls/examples
08 Context / Memory / Agents     #/context-agents/sources
  ├─ Context sources             #/context-agents/sources
  ├─ Compaction                  #/context-agents/compaction
  └─ Subagents                   #/context-agents/subagents
09 Capstone                      #/capstone/repository
  ├─ New repository              #/capstone/repository
  ├─ Investigation               #/capstone/investigation
  ├─ Plan / execution            #/capstone/plan
  └─ Verification                #/capstone/verification
```

Module progress is tracked at module boundaries, while previous/next controls move through every subpage.
