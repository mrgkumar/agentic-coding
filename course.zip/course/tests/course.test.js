import test from "node:test";
import assert from "node:assert/strict";
import {lessons,files,capstoneFiles} from "../src/content.js";

test("course has the required stable learning sequence",()=>assert.deepEqual(lessons.map(x=>x.id),["start","agent","context","research","plan","execution","verification","controls","context-agents","capstone"]));
test("case study and capstone remain synthetic and modular",()=>{assert.match(files["src/calculator.js"],/calculateBill/);assert.match(capstoneFiles["README.md"],/Pulse Monitor/);assert.equal(Object.keys(files).length,4)});
test("content preserves the three distinct control questions",()=>{const source=lessons.map(x=>x.objective).join(" ");assert.match(source,/plan/i);assert.equal(new Set(lessons.map(x=>x.progress)).size>1,true);});
