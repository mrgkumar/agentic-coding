export const lessons=[
 {id:"start",title:"Start",short:"Start",progress:"Context",objective:"Set the learning contract: control an engineering agent, instead of trying to prompt it perfectly."},
 {id:"agent",title:"From Chat to Agent",short:"Agent",progress:"Context",objective:"Recognize how tools and iterative observations turn a model into an acting system."},
 {id:"context",title:"Build Context",short:"Context",progress:"Context",objective:"Build relevant repository context in a deliberate ladder."},
 {id:"research",title:"Research Before Editing",short:"Research",progress:"Research",objective:"Separate evidence from assumptions before touching code."},
 {id:"plan",title:"Plan the Change",short:"Plan",progress:"Plan",objective:"Review for a smallest coherent change and protect what must remain stable."},
 {id:"execution",title:"Control Execution",short:"Execute",progress:"Execute",objective:"Keep plan, /goal, and /loop distinct while retaining human control."},
 {id:"verification",title:"Verify & Accept",short:"Verify",progress:"Verify",objective:"Decide whether a goal is met and whether the change is acceptable."},
 {id:"controls",title:"Tools, Permissions & Hooks",short:"Guardrails",progress:"Guardrails",objective:"Distinguish guidance, capability, boundary, and deterministic control."},
 {id:"context-agents",title:"Context, Memory & Subagents",short:"Context + agents",progress:"Guardrails",objective:"Keep working context useful and delegate only when separation adds value."},
 {id:"capstone",title:"Capstone",short:"Capstone",progress:"Capstone",objective:"Apply the full workflow to a new ambiguous repository scenario."}
];

export const files={
 "README.md":"# Shopping Calculator\nA small browser-based calculator. Run `npm test` and serve the folder over HTTP.",
 "package.json":"{ \"scripts\": { \"test\": \"node --test\" } }",
 "src/calculator.js":"calculateBill({ price, quantity, discountType, discountValue, taxRate })\n  validateInputs(...)\n  subtotal = price * quantity\n  discount and tax are calculated by discount type\n  return { subtotal, discount, tax, total }",
 "tests/calculator.test.js":"percentage discount returns subtotal, discount, tax, and total\nnegative prices are rejected\nfixed coupons cannot reduce a bill below zero"
};

export const capstoneFiles={
 "README.md":"Pulse Monitor\nA small service reports whether a heartbeat is healthy. Product wants a new status label, but the label's exact wording and HTTP contract are not stated.",
 "src/monitor.js":"export function getStatus(lastSeen, now) { /* existing monitoring logic */ }\n// callers consume the current status string",
 "tests/monitor.test.js":"healthy heartbeat remains healthy\nstale heartbeat is reported as stale"
};
